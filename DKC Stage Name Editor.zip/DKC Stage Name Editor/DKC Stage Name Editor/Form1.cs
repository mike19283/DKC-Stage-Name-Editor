﻿using System;
using System.Media;
using System.Windows.Forms;

namespace DKC_Stage_Name_Editor
{
    public partial class Form1 : Form
    {
        ROM rom;
        int selectedIndex;
        #region FormLoad
        public Form1()
        {
            InitializeComponent();
            Version.CheckUpdate(true);
            Defaults.InitDefaults();
            this.Text = "DKC Stage Name Editor v" + Version.GetVersion();
        }
        private void loadToolStripMenuItem_Click(object sender, EventArgs e)
        {

            rom = new ROM();
            rom.Load();
            if (rom.fileName != null)
            {
                loadToolStripMenuItem.Enabled = false;
                panel1.Visible = true;
                timer_save.Enabled = true;
                textBox_saveAs.Text = $"{rom.file} (edited)";
                // Populate listBox
                foreach (var stage in rom.GetWRAM())
                {
                    listBox_stageList.Items.Add(stage);
                }
                listBox_stageList.SelectedIndex = 0;
                textBox_custom.Focus();

            }
            else
            {
                // Clear just to be safe
                rom = null;
            }

        }
        #endregion
        private void checkForUpdateToolStripMenuItem_Click(object sender, EventArgs e) => Version.CheckUpdate(false);
        private void exitToolStripMenuItem_Click(object sender, EventArgs e) => Application.Exit();
        #region Save
        private void timer_save_Tick(object sender, EventArgs e)
        {
            button_saveAs.Enabled = !rom.IsWRAMEqualToSRAM();
        }
        private void button_saveAs_Click(object sender, EventArgs e)
        {
            Save(textBox_saveAs.Text);
        }

        private void Save(string fileName)
        {
            if (!rom.IsWRAMEqualToSRAM())
            {
                if (textBox_saveAs.Text == rom.file)
                {
                    MessageBox.Show("Careful! If you choose the exact same name, the base ROM will be overwritten!", "DKC Stage Name Editor");
                    if (MessageBox.Show("Continue?", "DKC Stage Name Editor", MessageBoxButtons.YesNo, MessageBoxIcon.Asterisk) != DialogResult.Yes)
                    {
                        return;
                    }
                }
                try
                {
                    rom.Save(fileName);
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            } 
            else
            {
                MessageBox.Show("No changes detected!", "DKC Stage Name Editor");
            }
        }

        private void textBox_saveAs_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Return)
            {
                Save(textBox_saveAs.Text);
                e.Handled = true;
            }

        }
        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (rom != null && !rom.IsWRAMEqualToSRAM())
            {
                MessageBox.Show("WARNING! You have unsaved work!", "DKC Stage Name Editor");
                if (MessageBox.Show("Close?", "DKC Stage Name Editor", MessageBoxButtons.YesNo, MessageBoxIcon.Asterisk) == DialogResult.No)
                {
                    e.Cancel = true;
                }
            }
        }

        #endregion
        #region StageEdit
        private void listBox_stageList_SelectedIndexChanged(object sender, EventArgs e)
        {
            selectedIndex = listBox_stageList.SelectedIndex;
            label_selectedStage.Text = ((Stage)listBox_stageList.Items[selectedIndex]).ToString();
            textBox_custom.Clear();
            textBox_custom.Focus();
        }

        private void button_confirm_Click(object sender, EventArgs e)
        {
            Confirm();
        }
        private void Refresh()
        {
            // Clear list
            listBox_stageList.Items.Clear();
            // Populate listBox
            foreach (var stage in rom.GetWRAM())
            {
                listBox_stageList.Items.Add(stage);
            }
            listBox_stageList.SelectedIndex = selectedIndex;

        }

        private void textBox_custom_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Return)
            {
                Confirm();
                e.Handled = true;

            }
        }
        private void Confirm()
        {
            // Get our current index
            selectedIndex = listBox_stageList.SelectedIndex;
            // Get our object
            var selected = (Stage)listBox_stageList.SelectedItem;

            // Find our object in WRAM
            foreach (var stage in rom.GetWRAM())
            {
                // Does level codes match?
                if (stage.GetLevelCode() == selected.GetLevelCode())
                {
                    stage.SetName(textBox_custom.Text);
                    // Set our display too
                    selected.SetName(textBox_custom.Text);
                    label_selectedStage.Text = textBox_custom.Text;
                    textBox_custom.Clear();
                    Refresh();
                    // We are done here
                    break;
                }
            }

        }

        private void textBox_custom_KeyPress(object sender, KeyPressEventArgs e)
        {
            var x = e.GetType();
            if (e.KeyChar == (char)Keys.Return)
            {
                e.Handled = true;
            }            
            if (!Defaults.allowedCharacters.Contains(e.KeyChar.ToString()) && e.KeyChar != (char)Keys.Back && e.KeyChar != (char)Keys.Return)
            {
                e.Handled = true;
                SystemSounds.Hand.Play();
            }
            
        }
        #endregion
        #region About
        string about =
            "________________________\n" +
            "|                                        |\n" +
            "|DKC Stage Name Editor|\n" +
            "|________________________|\n" +
            "September 1st, 2019\n" +
            "\n" +
            "This program was created with\n" +
            "C# by Michael Mingrone. Please\n" +
            "e-mail mikemingrone@gmail.com \n" +
            "with any inquiries.";

        private void aboutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show(about);
        }
        #endregion

    }
}
