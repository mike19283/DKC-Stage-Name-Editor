﻿using System;
using System.IO;
using System.Windows.Forms;

namespace DKC_Stage_Name_Editor
{
    public partial class ROM
    {
        public byte[] rom = new byte[0x400000];
        private byte[] dkcHeaderTitle = new byte[] { 0x44, 0x4F, 0x4E, 0x4B, 0x45, 0x59, 0x20, 0x4B, 0x4F, 0x4E, 0x47, 0x20, 0x43, 0x4F, 0x55, 0x4E, 0x54, 0x52, 0x59, 0x20, 0x20 };
        private int pointerStartAddress = 0x38a1e2;
        private int pointerEndAddress = 0x38a245;
        private int pointerArraySize;
        private byte[] originalPointers = new byte[] { 0x8, 0xA5, 0xD, 0xA5, 0x1A, 0xA5, 0x29, 0xA5, 0x3D, 0xA5, 0x4B, 0xA5, 0x59, 0xA5, 0x66, 0xA5, 0x75, 0xA5, 0x84, 0xA5, 0x94, 0xA5, 0xA5, 0xA5, 0xB6, 0xA5, 0xC5, 0xA5, 0xCF, 0xA5, 0xE0, 0xA5, 0xEC, 0xA5, 0xFD, 0xA5, 0x8, 0xA6, 0x17, 0xA6, 0x23, 0xA6, 0x2C, 0xA6, 0x3C, 0xA6, 0x4A, 0xA6, 0x5B, 0xA6, 0x68, 0xA6, 0x75, 0xA6, 0x87, 0xA6, 0x96, 0xA6, 0xA3, 0xA6, 0xB1, 0xA6, 0xC3, 0xA6, 0xD1, 0xA6, 0xE2, 0xA6, 0xF0, 0xA6, 0xFC, 0xA6, 0x8, 0xA7, 0x13, 0xA7, 0x22, 0xA7, 0x3A, 0xA7, 0x47, 0xA7, 0x59, 0xA7, 0x65, 0xA7, 0x74, 0xA7, 0x89, 0xA7, 0x97, 0xA7, 0xA6, 0xA7, 0xB8, 0xA7, 0xC6, 0xA7, 0xD5, 0xA7 };
        private string path;
        public string file;
        public string fileName;
        #region Load
        public void Load ()
        {
            OpenFileDialog d = new OpenFileDialog();
            d.Filter = "ROM file (*.smc;*.sfc)|*.smc;*.sfc";
            d.Title = "Select a proper DKC ROM";

            while (d.ShowDialog() == DialogResult.OK)
            {
                try
                {
                    byte[] temp = File.ReadAllBytes(d.FileName);
                    // Start reading after the header
                    Int32 startingPoint = temp.Length == 0x400000 + 0x200 ? 0x200 : 0;
                    Array.Copy(temp, startingPoint, rom, 0, 0x400000);
                    // Check ROM cartridge header
                    byte[] tempArr = new byte[dkcHeaderTitle.Length/*0xffd5 - 0xffc0*/];
                    Array.Copy(rom, 0xffc0, tempArr, 0, dkcHeaderTitle.Length/*0xffd5 - 0xffc0*/);
                    if (AreArraysTheSame(dkcHeaderTitle, tempArr) && rom[0xffdb] == 0)
                    {
                        // All tests pass
                        fileName = d.FileName;
                        int index = fileName.LastIndexOf("\\");
                        path = fileName.Substring(0, index + 1);
                        file = fileName.Substring(index + 1, fileName.Length - index - 1 - 4);

                        // Check the file
                        if (!ArePointersChanged())
                        {
                            MessageBox.Show("All custom text will be changed!", "DKC Stage Name Editor");
                            AdjustTextBank();
                        }
                        else
                        {
                            SaveWRAMToSRAM();
                        }
                        Init();
                        break;
                    }
                    else
                    {
                        MessageBox.Show("Invalid file", "DKC Stage Name Editor");
                        continue;
                    }

                }
                catch (Exception ex)
                {
                    MessageBox.Show("Invalid file", "DKC Stage Name Editor");
                }
            }
        }
        // Compare bytes of two arrays
        public bool AreArraysTheSame(byte[] arr1, byte[] arr2)
        {
            for (int i = 0; i < arr1.Length && i < arr2.Length; i++)
            {
                if (arr1[i] != arr2[i])
                    return false;
            }
            return true;
        }

        private bool ArePointersChanged()
        {
            pointerArraySize = pointerEndAddress - pointerStartAddress;
            var temp = new byte[pointerArraySize];
            Array.Copy(rom, pointerStartAddress, temp, 0, pointerArraySize);
            return AreArraysTheSame(Defaults.customPointerAsBytes.ToArray(), temp);
        }
        private void AdjustTextBank ()
        {
            var tempIndex = pointerStartAddress;
            foreach (var @byte in Defaults.customPointerAsBytes)
            {
                rom[tempIndex++] = @byte;
            }
            // Custom Names has the pointers with their original name
            foreach (var key in Defaults.customNames.Keys)
            {
                WriteToROM(key, WriteArray(Defaults.customNames[key]));
            }
        }

        private void FillWRAM ()
        {
            // Loop through stage order
            foreach (var stage in Defaults.stagesInOrder)
            {
                // Loop through pointers/names
                foreach (var key in Defaults.customNames.Keys)
                {
                    var temp = Defaults.customNames[key];
                    if (temp != stage)
                    {
                        continue;
                    }
                    if (temp.Contains("ERROR") || temp.Contains("Funky") || temp.Contains("Candy") || temp.Contains("Cranky"))
                    {
                        continue;
                    }
                    // Get default name
                    string tempStr = Defaults.customNames[key];
                    byte temp3e = Defaults.stagesWeCanEdit3e[tempStr];
                    // Read name from ROM
                    tempStr = GetStageAsString(temp3e);

                    GetWRAM().Add(new Stage(tempStr, temp3e, key));

                    // We finished
                    break;
                }
            }
        }
        private void Init()
        {
            FillWRAM();
            SaveWRAMToSRAM();
        }
        #endregion
        // A helper
        // Read 16 bits from little endian format
        public UInt16 Read16(Int32 address)
        {
            address &= 0x3fffff;
            return (UInt16)(
                (rom[address++] << 0) |
                (rom[address++] << 8));
        }
        // Write 16 bits in little endian mode
        public void Write16(Int32 address, Int32 value)
        {
            address &= 0x3fffff;
            rom[address++] = (byte)(value >> 0);
            rom[address++] = (byte)(value >> 8);
        }
    }
}
