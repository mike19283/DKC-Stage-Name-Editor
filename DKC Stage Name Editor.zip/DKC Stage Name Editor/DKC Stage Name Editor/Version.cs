﻿using System;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DKC_Stage_Name_Editor
{
    static class Version
    {
        private static string versionString = "1.00";

        public static void CheckUpdate(bool firstTime)
        {
            Task.Run(() =>
            {
                try
                {
                    // Get current version from my pastebin
                    System.Net.WebClient wc = new System.Net.WebClient();
                    byte[] raw = wc.DownloadData("https://pastebin.com/L41RpkNU");

                    // Parse the string
                    String webData = System.Text.Encoding.UTF8.GetString(raw);
                    // ...<title>Version# - ...
                    var websiteArr = Regex.Split(webData, "uniquetext19283");
                    string websiteVer = websiteArr[3];
                    var tempArr = Regex.Split(websiteVer, "\r\n");
                    websiteVer = tempArr[1];
                    string downloadLink = tempArr[2];

                    // Are we running the most current version?
                    if (versionString != websiteVer)
                    {
                        MessageBox.Show($"An update is currently available.", "DKC Stage Name Editor");
                        if (MessageBox.Show("Would you like to update now?", "DKC Stage Name Editor", MessageBoxButtons.YesNo, MessageBoxIcon.Asterisk) == DialogResult.Yes)
                        {
                            System.Diagnostics.Process.Start(downloadLink);
                            Application.Exit();
                        }
                    }
                    else
                    {
                        if (!firstTime)
                            MessageBox.Show("You already own the latest version!", "DKC Stage Name Editor");
                    }
                }

                catch (Exception ex)
                {
                    MessageBox.Show("Trouble connecting to the internet. You may be running outdated software!", "DKC Stage Name Editor");
                }

            });
        }

        public static string GetVersion() => versionString;

    }
}
