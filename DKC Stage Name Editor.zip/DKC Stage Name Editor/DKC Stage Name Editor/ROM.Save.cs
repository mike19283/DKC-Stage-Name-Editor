﻿using System.Collections.Generic;

namespace DKC_Stage_Name_Editor
{
    public partial class ROM
    {
        private static List<Stage> SRAM = new List<Stage>();
        private static List<Stage> WRAM = new List<Stage>();

        public List<Stage> GetSRAM() => SRAM;
        public List<Stage> GetWRAM() => WRAM;

        public bool IsWRAMEqualToSRAM()
        {
            for (int i = 0; i < WRAM.Count && i < SRAM.Count; i++)
            {
                if (WRAM[i].GetName() != SRAM[i].GetName())
                {
                    return false;
                }
            }
            return WRAM.Count == SRAM.Count;
        }
        public void SaveWRAMToSRAM()
        {
            // Clear SRAM before saving
            SRAM = new List<Stage>();
            // Loopthrough WRAM
            foreach (var stage in WRAM)
            {
                // Deep copy members
                var tempString = stage.GetName();
                var tempByte = stage.GetLevelCode();
                var tempInt = stage.GetPointer();
                SRAM.Add(new Stage(tempString, tempByte, tempInt));
            }
        }
        public void Save(string saveAs)
        {
            WriteWRAMToROM();
            SaveROM(saveAs);
            SaveWRAMToSRAM();
        }
        private void WriteWRAMToROM()
        {
            // Loop through SRAN
            foreach (var stage in WRAM)
            {
                // Write each to ROM
                WriteToROM(stage.GetPointer(), WriteArray(stage.GetName()));
            }
        }
        private void SaveROM(string saveAs)
        {
            System.IO.File.WriteAllBytes($"{path}{saveAs}.smc" , rom);
        }
    }
}
